import {Login} from '../components/Login' ; 
import { Register } from '../components/Register';
import React from 'react' ; 

export const Home =()=>{
    return(
        <>
        <h1 className = 'alert-success text-center'>Music App</h1>
        <Login/>
        <hr/>
        <Register/>
        </>
    );
}